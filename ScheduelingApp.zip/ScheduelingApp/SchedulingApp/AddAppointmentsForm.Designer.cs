﻿namespace SchedulingApp
{
    partial class AddAppointmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustomerNameLabel = new Label();
            AppointmentTypeLabel = new Label();
            StartTimeLabel = new Label();
            DateLabel = new Label();
            CustomerNameTextBox = new TextBox();
            BackButton = new Button();
            SaveButton = new Button();
            StartTimeComboBox = new ComboBox();
            dateTimePicker = new DateTimePicker();
            label1 = new Label();
            AppointmentTypeTextBox = new ComboBox();
            SuspendLayout();
            // 
            // CustomerNameLabel
            // 
            CustomerNameLabel.AutoSize = true;
            CustomerNameLabel.Location = new Point(23, 15);
            CustomerNameLabel.Name = "CustomerNameLabel";
            CustomerNameLabel.Size = new Size(94, 15);
            CustomerNameLabel.TabIndex = 0;
            CustomerNameLabel.Text = "Customer Name";
            // 
            // AppointmentTypeLabel
            // 
            AppointmentTypeLabel.AutoSize = true;
            AppointmentTypeLabel.Location = new Point(12, 44);
            AppointmentTypeLabel.Name = "AppointmentTypeLabel";
            AppointmentTypeLabel.Size = new Size(105, 15);
            AppointmentTypeLabel.TabIndex = 1;
            AppointmentTypeLabel.Text = "Appointment Type";
            // 
            // StartTimeLabel
            // 
            StartTimeLabel.AutoSize = true;
            StartTimeLabel.Location = new Point(47, 102);
            StartTimeLabel.Name = "StartTimeLabel";
            StartTimeLabel.Size = new Size(70, 15);
            StartTimeLabel.TabIndex = 2;
            StartTimeLabel.Text = "Time in UTC";
            // 
            // DateLabel
            // 
            DateLabel.AutoSize = true;
            DateLabel.Location = new Point(86, 73);
            DateLabel.Name = "DateLabel";
            DateLabel.Size = new Size(31, 15);
            DateLabel.TabIndex = 3;
            DateLabel.Text = "Date";
            // 
            // CustomerNameTextBox
            // 
            CustomerNameTextBox.Location = new Point(123, 12);
            CustomerNameTextBox.Name = "CustomerNameTextBox";
            CustomerNameTextBox.Size = new Size(279, 23);
            CustomerNameTextBox.TabIndex = 4;
            // 
            // BackButton
            // 
            BackButton.Location = new Point(327, 134);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(75, 23);
            BackButton.TabIndex = 8;
            BackButton.Text = "Cancel";
            BackButton.UseVisualStyleBackColor = true;
            BackButton.Click += BackButton_Click;
            // 
            // SaveButton
            // 
            SaveButton.Location = new Point(246, 134);
            SaveButton.Name = "SaveButton";
            SaveButton.Size = new Size(75, 23);
            SaveButton.TabIndex = 9;
            SaveButton.Text = "Save";
            SaveButton.UseVisualStyleBackColor = true;
            SaveButton.Click += SaveButton_Click;
            // 
            // StartTimeComboBox
            // 
            StartTimeComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            StartTimeComboBox.FormattingEnabled = true;
            StartTimeComboBox.Items.AddRange(new object[] { "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM", "9:30 PM", "10:00 PM" });
            StartTimeComboBox.Location = new Point(123, 99);
            StartTimeComboBox.Name = "StartTimeComboBox";
            StartTimeComboBox.Size = new Size(279, 23);
            StartTimeComboBox.TabIndex = 10;
            // 
            // dateTimePicker
            // 
            dateTimePicker.Location = new Point(123, 70);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.Size = new Size(279, 23);
            dateTimePicker.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 125);
            label1.Name = "label1";
            label1.Size = new Size(138, 15);
            label1.TabIndex = 23;
            label1.Text = "(Between 9AM-5PM EST)";
            // 
            // AppointmentTypeTextBox
            // 
            AppointmentTypeTextBox.DropDownStyle = ComboBoxStyle.DropDownList;
            AppointmentTypeTextBox.FormattingEnabled = true;
            AppointmentTypeTextBox.Items.AddRange(new object[] { "Scrum", "Meeting", "Presentation", "Lunch", "Tea Time", "Magic The Gathering Game", "Yu Gi Oh Game" });
            AppointmentTypeTextBox.Location = new Point(123, 41);
            AppointmentTypeTextBox.Name = "AppointmentTypeTextBox";
            AppointmentTypeTextBox.Size = new Size(279, 23);
            AppointmentTypeTextBox.TabIndex = 24;
            // 
            // AddAppointmentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(419, 171);
            Controls.Add(AppointmentTypeTextBox);
            Controls.Add(label1);
            Controls.Add(dateTimePicker);
            Controls.Add(StartTimeComboBox);
            Controls.Add(SaveButton);
            Controls.Add(BackButton);
            Controls.Add(CustomerNameTextBox);
            Controls.Add(DateLabel);
            Controls.Add(StartTimeLabel);
            Controls.Add(AppointmentTypeLabel);
            Controls.Add(CustomerNameLabel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximumSize = new Size(435, 210);
            MinimumSize = new Size(435, 210);
            Name = "AddAppointmentForm";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Add Appointment";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label CustomerNameLabel;
        private Label AppointmentTypeLabel;
        private Label StartTimeLabel;
        private Label DateLabel;
        private TextBox CustomerNameTextBox;
        private Button BackButton;
        private Button SaveButton;
        private ComboBox StartTimeComboBox;
        public DateTimePicker dateTimePicker;
        private Label label1;
        private ComboBox AppointmentTypeTextBox;
    }
}